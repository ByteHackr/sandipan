THIS IS MY SHORT BIODATA.

I make it only for FUN.

Born and raised in India. I'm a Computer Science student with a passion for coding & testing and interested in IT Security. Recently completed M.Sc in Computer Science from West Bengal State University with a demonstrated history of working in the computer and network security, software testing & IT Security & automation.I’m truly passionate about my work and always increase my knowledge. I also like to try new technologies and improve myself under each point of view.Currently working as a Security Engineer at Parrot Security.


Contact Me:

Email: sandipan@parrotsec.org) or me@sandipan.ml

Twitter: twitter.com/bytehackr

Linkedin: linkedin/in/bytehackr

Instagram: instagram.com/bytehackr
