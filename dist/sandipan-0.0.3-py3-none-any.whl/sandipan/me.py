# -*- coding: utf-8 -*-


def personal_details():
    name, age = "Sandipan Roy", 20
    address = "Berhampore, West Bengal, India"
    print("Name: {}\nAge: {}\nAddress: {}".format(name, age, address))
def social_links():
    twitter = "twitter.com/bytehackr"
    linkedin = "linkedin/in/bytehackr"
    email = "me@sandipan.ml"
    print("Email: {}\nTwitter: {}\nLinkedin: {}".format(email, twitter, linkedin))

personal_details()
social_links()
