# -*- coding: utf-8 -*-


def personal_details():
    name, age = "Sandipan Roy", 23
    address = "Berhampore, West Bengal, India"
    print("Name: {}\nAge: {}\nAddress: {}".format(name, age, address))
def social_links():
    twitter = "twitter.com/bytehackr"
    linkedin = "linkedin/in/bytehackr"
    instagram = "instagram.com/bytehackr"
    email = "'sandipan@parrotsec.org' or 'me@sandipan.ml'"
    print("Email: {}\nTwitter: {}\nLinkedin: {}".format(email, twitter, linkedin))


print("-----------------")
personal_details()
print("-----------------")
social_links()
